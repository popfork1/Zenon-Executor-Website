Hello! Thank you for downloading Zenon Executor.

Before you get started, make sure that your Roblox version is db4634f0e27d4d36.
If you are unsure, then just go ahead and download the version here:
https://rdd.weao.gg/?channel=LIVE&binaryType=WindowsPlayer&version=version-db4634f0e27d4d36&includeLauncher=true
You need to download this because the executor is currently down for the latest Roblox version, so you need to downgrade Roblox.

What is downgrading Roblox doing?
Well, downgrading Roblox is what it is called. It downgrades the Roblox version. So if there is a roblox update, then you can downgrade Roblox and the executor will work!

Where can I downgrade Roblox?
You can downgrade Roblox here: rdd.weao.gg

What version should I downgrade to when the executor is down because of an update?
You should downgrade to the previous version by pressing "Download Previous Version" on the website.

Why is it still saying that there is a Roblox version mismatch even if I downgraded Roblox to the previous version?
It might still be saying this because there might be multiple released updates in a row. In that case, you would just have to look in the discord for the version to downgrade to.

How can I put in my own custom version to downgrade to that is specified in the Discord?
In order to downgrade to a custom version, you must copy the version number, (Ex:db4634f0e27d4d36) and then put it in the website under "Version Hash" and then click "Download Specified Hash"